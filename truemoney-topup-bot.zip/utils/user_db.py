import json
from decimal import Decimal
from pathlib import Path

USER_FILE = Path("data/users.json")

def load_users():
    if USER_FILE.exists():
        with open(USER_FILE, "r", encoding="utf-8") as f:
            return json.load(f, parse_float=Decimal)
    return {}

def save_users(data):
    with open(USER_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)
