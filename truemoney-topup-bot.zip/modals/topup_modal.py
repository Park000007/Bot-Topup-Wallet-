import nextcord
from nextcord import Embed, Color
from decimal import Decimal, ROUND_HALF_UP
import requests, time, datetime
import config
from utils.user_db import load_users, save_users

class popuptopup(nextcord.ui.Modal):
    def __init__(self):
        super().__init__(title="🧧 เติมเงินผ่านซองอั่งเปา (มีค่าธรรมเนียม)")
        self.link = nextcord.ui.TextInput(
            label="🔗 ลิงก์ซองอั่งเปา TrueMoney",
            placeholder="https://gift.truemoney.com/campaign/?v=...",
            required=True,
            min_length=1,
            max_length=1000,
        )
        self.add_item(self.link)

    async def callback(self, interaction: nextcord.Interaction):
        loaduser = load_users()
        user_id = str(interaction.user.id)

        if not self.link.value.startswith("https://gift.truemoney.com/campaign/?v="):
            return await interaction.response.send_message(
                "❌ ลิงก์ซองไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง!", ephemeral=True
            )

        loading_embed = Embed(
            title="⏳ กำลังตรวจสอบซองอั่งเปา...",
            description="ระบบกำลังดำเนินการ กรุณารอสักครู่...",
            color=Color.purple()
        )
        await interaction.response.send_message(embed=loading_embed, ephemeral=True)

        payload = {
            "phone": config.phone,
            "vouch": self.link.value
        }
        headers = {
            "X-API-Key": config.API_KEY
        }

        try:
            r = requests.post(
                "https://api.xznp.store/api/wallet/topup",
                json=payload,
                headers=headers,
                timeout=15
            )
            r.raise_for_status()
            x = r.json()

            if x.get('status', False):
                full_amount = Decimal(str(x['message']['my_ticket']['amount_baht'])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                fee_percent = getattr(config, 'FEE_PERCENTAGE', Decimal('1.1'))
                fee = (full_amount * Decimal(fee_percent) / 100).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                credited_amount = (full_amount - fee).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

                loaduser.setdefault(user_id, {"money": Decimal('0.00'), "point": Decimal('0.00')})
                loaduser[user_id]['point'] += credited_amount
                save_users(loaduser)

                embed_success = Embed(title="🎉 เติมเงินสำเร็จ!", color=Color.green())
                embed_success.set_author(name=interaction.user.name, icon_url=interaction.user.display_avatar.url)
                embed_success.add_field(name="💵 จำนวนเงิน", value=f"{full_amount:.2f} บาท", inline=True)
                embed_success.add_field(name="📉 ค่าธรรมเนียม", value=f"{fee:.2f} บาท", inline=True)
                embed_success.add_field(name="🟢 เครดิตที่ได้รับ", value=f"{credited_amount:.2f} บาท", inline=True)
                embed_success.set_footer(text=config.footer)
                embed_success.timestamp = datetime.datetime.utcnow()

                await interaction.edit_original_message(embed=embed_success)
            else:
                await interaction.edit_original_message(content="❌ ลิงก์ไม่ถูกต้องหรือถูกใช้ไปแล้ว")

        except Exception as e:
            await interaction.edit_original_message(content=f"เกิดข้อผิดพลาด: {e}")
