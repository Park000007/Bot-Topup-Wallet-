import nextcord
from nextcord.ext import commands
from modals.topup_modal import popuptopup
import config

intents = nextcord.Intents.default()
bot = commands.Bot(command_prefix="/", intents=intents)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.slash_command(name="topup", description="เติมเงินผ่านซองอั่งเปา")
async def topup(interaction: nextcord.Interaction):
    await interaction.response.send_modal(popuptopup())

bot.run(config.BOT_TOKEN)
