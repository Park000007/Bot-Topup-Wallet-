from decimal import Decimal

BOT_TOKEN = "YOUR_DISCORD_BOT_TOKEN"
API_KEY = "YOUR_API_KEY"
phone = "YOUR_TRUEMONEY_PHONE"
ChannelLOGMoney = 123456789012345678
footer = "© XZNP System"
FEE_PERCENTAGE = Decimal('1.1')
